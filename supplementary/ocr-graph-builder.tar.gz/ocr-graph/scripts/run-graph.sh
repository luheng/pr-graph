export WDIR="/home/luheng/Working/ocr-graph"
export CLASSPATH="$WDIR/bin/:$WDIR/libs/trove-2.0.2.jar:$WDIR/libs/args4j-2.0.10.jar:$WDIR/libs/libemd_hat_native.so"

java -cp $CLASSPATH -Xmx8000m OcrGraphBuilder
