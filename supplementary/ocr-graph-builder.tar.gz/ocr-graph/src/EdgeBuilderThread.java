import data.Edge;
import data.OcrLetterNode;
import data.OcrLetterSequence;

public class EdgeBuilderThread extends Thread {
	int start, end, id;
	boolean finished;
	OcrGraphBuilder graph;
	static double extraMassPenalty;
	static double deltaSquared;
	static double cosineSimThreshold;
	static double centerSimWeight;
	static double boundarySim;

	public EdgeBuilderThread(int id, int start, int end, OcrGraphBuilder graph) {
		this.id = id;
		this.start = start;
		this.end = end;
		this.finished = false;
		this.graph = graph;
		
		extraMassPenalty = graph.config.extraMassPenalty;
		deltaSquared = graph.config.deltaSquared;
		cosineSimThreshold = graph.config.cosineSimThreshold;
		centerSimWeight = graph.config.centerSimWeight;
		boundarySim = graph.config.boundarySim;
	}

	static final int LENGTH = 128;
	static final int maxSequenceLength = 100;
	final double[][] simCache = new double[maxSequenceLength][maxSequenceLength];
	final boolean[][] toCompute = new boolean[maxSequenceLength][maxSequenceLength];
	
	@Override
	public void run() {
		double beta = (1 - centerSimWeight) / 2;
		
		for(int i = start; i < end; i++) {
			OcrLetterSequence word1 = graph.words.get(i);
			
			for(int j = 0; j < graph.numWords; j++) {
				OcrLetterSequence word2 = graph.words.get(j);
				
				for (int k1 = 0; k1 < word1.length; k1++) { 
					for (int k2 = 0; k2 < word2.length; k2++) {
						toCompute[k1][k2] = false;
					}
				}
				for (int k1 = 0; k1 < word1.length; k1++) {
					for (int k2 = 0; k2 < word2.length; k2++) {
						if (i != j || k1 != k2) {
							OcrLetterNode n1 = graph.nodes.
									get(word1.startLetterID + k1);
							OcrLetterNode n2 = graph.nodes.
									get(word2.startLetterID + k2);
							if (n1.cosineSimilarity(n2) > cosineSimThreshold) {
								toCompute[k1][k2] = true;
							}
						}
					}
				}
				for(int k1 = 0; k1 < word1.length; k1++) { 
					for(int k2 = 0; k2 < word2.length; k2++) {
						OcrLetterNode n1 = graph.nodes.
								get(word1.startLetterID + k1);
						OcrLetterNode n2 = graph.nodes.
								get(word2.startLetterID + k2);
						if (toCompute[k1][k2]) {
							double dist = emd_hat.native_dist_compute(
									n1.pixels, n2.pixels,
									OcrGraphBuilder.groundDist, 
									extraMassPenalty, null, LENGTH, 1, 1); 
							simCache[k1][k2] = Math.exp(-dist / deltaSquared); 
						}
						else {
							simCache[k1][k2] = .0;
						}
					}
				}			
				for (int k1 = 0; k1 < word1.length; k1++) { 
					for (int k2 = 0; k2 < word2.length; k2++) {
						if (!toCompute[k1][k2]) {
							continue;
						}
						int t1 = word1.startLetterID + k1;
						int t2 = word2.startLetterID + k2;
						if (centerSimWeight > 0.999) { 
							graph.edges[t1].add(new Edge(t2, simCache[k1][k2]));
						} else {
							double sim = centerSimWeight * simCache[k1][k2];
							if (k1 == 0 && k2 == 0) { 
								sim += beta * boundarySim;
							} else if (k1 > 0 && k2 > 0) {
								sim += beta * simCache[k1-1][k2-1];
							}
							if (k1 == word1.length -1 && k2 == word2.length - 1) {
								sim += beta * boundarySim;
							} else if (k1 < word1.length -1 &&
									k2 < word2.length - 1) {
								sim += beta * simCache[k1+1][k2+1];
							}
							graph.edges[t1].add(new Edge(t2, sim));
						}
					}
				}
			}
			if (i > start && (i - start) % 10 == 0) {
				System.out.print(i + "...\t");
			}
		}
	}
}
