import java.io.PrintStream;

import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

public class GraphBuilderConfig {
	@Option(name = "-data-path", usage="")
	public String dataPath = "/home/luheng/Working/pr-graph/data/ocr/letter.data";
	
	@Option(name = "-output-path", usage="")
	public String outputPath = "ocr-test.grph";
	
	@Option(name = "-num-threads", usage="")
	public int numThreads= 4;
	
	@Option(name = "-num-neighbors", usage="")
	public int numNeighbors = 20;
	
	@Option(name = "-extra-mass-penalty", usage="")
	public double extraMassPenalty = -1;
	
	@Option(name = "-emd-threshold", usage="")
	public double emdThreshold = 3;
	
	@Option(name = "-cos-threshold", usage="")
	public double cosineSimThreshold = 0.3;
	
	@Option(name = "-center-weight", usage="")
	public double centerSimWeight = 0.8;
	
	@Option(name = "-boundary-sim", usage="")
	public double boundarySim = 0.6;
	
	@Option(name = "-delta-squared", usage="")
	public double deltaSquared = 100.0;
	
	public GraphBuilderConfig(String[] args) {
		CmdLineParser parser = new CmdLineParser(this);
		parser.setUsageWidth(120);
		try {
			parser.parseArgument(args);
		} catch (CmdLineException e) {
			e.printStackTrace();
		}
	}
	
	public void print(PrintStream ostr)	{
		ostr.println("-data-path\t" + dataPath);
		ostr.println("-output-path\t" + outputPath);
		ostr.println("-num-threads\t" + numThreads);
		ostr.println("-num-neighbors\t" + numNeighbors);
		ostr.println("-extra-mass-penalty\t" + this.extraMassPenalty);
		ostr.println("-EMD-threshold\t" + this.emdThreshold);
		ostr.println("-cosine-threshold\t" + this.cosineSimThreshold);
		ostr.println("-center-weight\t" + this.centerSimWeight);
		ostr.println("-boundary-sim\t" + this.boundarySim);
		ostr.println("-delta-squared\t" + this.deltaSquared);
	}
}
