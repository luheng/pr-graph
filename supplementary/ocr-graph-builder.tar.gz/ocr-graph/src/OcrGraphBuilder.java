import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import data.Edge;
import data.EdgeList;
import data.NodeLoader;
import data.OcrLetterNode;
import data.OcrLetterSequence;

public class OcrGraphBuilder {
	public ArrayList<OcrLetterNode> nodes;
	public ArrayList<OcrLetterSequence> words;
	public int numNeighbors, numNodes, numWords;
	public EdgeList[] edges;
	public static double[] groundDist;	
	public boolean mutualKnn = true;
	GraphBuilderConfig config;
	
	public OcrGraphBuilder(ArrayList<OcrLetterNode> nodes,
			ArrayList<OcrLetterSequence> words,	GraphBuilderConfig config) {
		this.nodes = nodes;
		this.words = words;
		this.config = config;
		this.numNeighbors = config.numNeighbors;
		this.numNodes = nodes.size();
		this.numWords = words.size();
		int nrRows = 16, nrCols = 8;
		int length = nrRows * nrCols;
		
		double[][] dist2D = new double[length][length];
		for (int i = 0; i < length; i++) {
			for (int j = 0; j < length; j++) {
				int r1 = i / nrCols, c1 = i % nrCols;  
				int r2 = j / nrCols, c2 = j % nrCols;
				double dist= Math.sqrt((r1-r2)*(r1-r2) + (c1-c2)*(c1-c2));
				dist2D[i][j]= config.emdThreshold < 0 ? dist2D[i][j] :
					Math.min(dist, config.emdThreshold);
			}
		}
		groundDist = emd_hat.convert_to_row_by_row(dist2D);
	}
	
	public void buildGraph() {
		System.out.println(String.format(
				"Going to build a graph with %d nodes ... ", nodes.size()));
		
		edges = new EdgeList[numNodes];
		for (int i = 0; i < numNodes; i++) {
			edges[i] = new EdgeList(numNeighbors);
		}
		int batchSize = numWords / config.numThreads + 1;
		EdgeBuilderThread[] threads = new EdgeBuilderThread[config.numThreads];
		for (int i = 0; i < config.numThreads; i++) {
			int start = i * batchSize;
			int end = Math.min(numWords, start + batchSize);
			threads[i] = new EdgeBuilderThread(i, start, end, this);
			threads[i].start();
		}
		for (int i = 0; i < config.numThreads; i++) {
			try {
				threads[i].join();
			} catch (InterruptedException e) {
			}
		}
	}
	
	public void symmetrify(String outputFilePath) throws IOException {
		for (int i = 0; i < numNodes; i++) { 
			edges[i].freeze();
		}
		int nrHarmfulEdges = 0, nrEdges = 0, nrUnsymEdges = 0, nrEmptyNodes = 0;
		double symErr = 0, unsymErr = 0, symWeightedErr = 0, unsymWeightedErr = 0;
		double symWeightNorm = 0, unsymWeightNorm = 0;
		double avgDegree = 0, maxDegree = -1, minDegree = Double.MAX_VALUE;

		for (int i = 0; i < numNodes; i++) {
			for (Iterator<Edge> itr = edges[i].iterator(); itr.hasNext(); ) {
				Edge e = itr.next();
				if (nodes.get(i).letter != nodes.get(e.neighbor).letter) {
					unsymErr ++;
					unsymWeightedErr += e.weight;
				}
				unsymWeightNorm += e.weight;
			}
			nrUnsymEdges += edges[i].size();
		}
		if (!mutualKnn) {
			for (int i = 0; i < numNodes; i++) {
				for (Iterator<Edge> itr = edges[i].iterator(); itr.hasNext(); ) {
					Edge e = itr.next();
					edges[e.neighbor].symAdd(new Edge(i, e.weight));
				}
			}
		}
		BufferedWriter fout = new BufferedWriter(new FileWriter(outputFilePath));
		for (int i = 0; i < numNodes; i++) {
			int degree = 0;
			for (Iterator<Edge> itr = edges[i].iterator(); itr.hasNext(); ) {
				Edge e = itr.next();
				double w = e.weight;
				int t = e.neighbor;
				if (e.weight == 0 || (mutualKnn  &&
						!edges[e.neighbor].contains(i))) {
					continue;
				}
				if (nodes.get(i).letter != nodes.get(t).letter) {
					++ nrHarmfulEdges;
					++ symErr;
					symWeightedErr += e.weight;
				}
				++ degree;
				++ nrEdges;
				symWeightNorm += w;
				fout.write(String.format("%d\t%d\t%.12f\n",
						i+1, e.neighbor+1, e.weight));
			}
			avgDegree += degree;
			maxDegree = Math.max(maxDegree, degree);
			minDegree = Math.min(minDegree, degree);
			nrEmptyNodes += degree == 0 ? 1 : 0;
		}
		fout.close();
		System.out.println("Averaged node degree: " + avgDegree / numNodes + 
							"\n Maximum node degree: " + maxDegree + 
							"\n Minimum node degree: " + minDegree + 
							"\n Number of nodes: " + numNodes + 
							String.format("\n Number of empty nodes: %d (%.2f%%)", 
									nrEmptyNodes, 100.0 * nrEmptyNodes / numNodes));
		
		System.out.println("unsymmetrified graph weight norm: " + unsymWeightNorm);
		System.out.println("graph weight norm: " + symWeightNorm);
		System.out.println("unsymmetrified number of edges: " + nrUnsymEdges);
		System.out.println("number of edges: " + nrEdges);
		System.out.println("unsymmetrified error rate: " + unsymErr / nrUnsymEdges + 
				"\t weighted: " + unsymWeightedErr / unsymWeightNorm);
		System.out.println("error rate: " + symErr / nrEdges + 
				"\t weighted: " + symWeightedErr / symWeightNorm);
		System.out.println(String.format("Number of suggested edges: %d,\t " +
				"number of harmful edges: %d,\tpercent of harmful edges: %.4f%%",
				nrEdges, nrHarmfulEdges, 100.0 * nrHarmfulEdges / nrEdges));
	}
	
	public double computeContextDepSimilarity(OcrLetterNode node1,
			OcrLetterNode node2) {
		double sim = 0,  simLeft = 0, simRight = 0;
		double dist = emd_hat.native_dist_compute(
				node1.pixels, node2.pixels, OcrGraphBuilder.groundDist, 
				config.extraMassPenalty, null, 128, 1, 1); 
		
		sim = Math.exp(-dist / config.deltaSquared); 
		if (node1.prev < 0 && node2.prev < 0) {
			simLeft = 1;
		} else if (node1.prev >= 0 && node2.prev >= 0) {
			simLeft = nodes.get(node1.prev).cosineSimilarity(nodes.
					get(node2.prev));
		}
		if (node1.next < 0 && node2.next < 0) { 
			simRight = 1;
		} else if (node1.next >= 0 && node2.next >= 0) {
			simRight = nodes.get(node1.next).cosineSimilarity(nodes
					.get(node2.next));
		}
		double beta = (1.0 - config.centerSimWeight) / 2;
		return sim * config.centerSimWeight + simLeft * beta + simRight * beta;
	}
	
	public static void main(String[] args) {
		GraphBuilderConfig config = new GraphBuilderConfig(args);
		config.print(System.out);
		ArrayList<OcrLetterNode> nodes = new ArrayList<OcrLetterNode>();
		ArrayList<OcrLetterSequence> words = new ArrayList<OcrLetterSequence>();
		try {
			NodeLoader.loadOCRNodes(config.dataPath, nodes, words,
					Integer.MAX_VALUE);
			OcrGraphBuilder graphBuilder = new OcrGraphBuilder(nodes, words,
					config);
			graphBuilder.buildGraph();	
			System.out.println("symmetrify ...");
			graphBuilder.symmetrify(config.outputPath);	
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
