package data;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

public class NodeLoader {
	public static void loadOCRNodes(String dataPath,
			ArrayList<OcrLetterNode> nodes, ArrayList<OcrLetterSequence> words)
					throws IOException {
		NodeLoader.loadOCRNodes(dataPath, nodes, words, Integer.MAX_VALUE);
	}

	public static void loadOCRNodes(String dataPath,
			ArrayList<OcrLetterNode> nodes, ArrayList<OcrLetterSequence> words, 
			int maxNrNodes) throws NumberFormatException, IOException {
		String currLine;
		BufferedReader reader = new BufferedReader(new FileReader(dataPath));
		int headID = 0;
		while ((currLine = reader.readLine()) != null) {			
			String[] info = currLine.trim().split("\t");
			
			int nodeID = Integer.parseInt(info[0]) - 1;
			char letter = info[1].charAt(0) ;
			int nextID = Integer.parseInt(info[2]) - 1;
			int seqID = Integer.parseInt(info[3]) - 1;
			int seqPos = Integer.parseInt(info[4]) - 1;
			
			double[] pixels = new double[info.length - 6];
			for(int i = 6; i < info.length; i++) {
				pixels[i-6] = info[i].charAt(0) - '0';
			}
			
			OcrLetterNode newNode = new OcrLetterNode(nodeID, seqID, seqPos,
					letter, pixels); 
			nodes.add(newNode);
			newNode.prev = nodeID == headID ? -1 : nodeID - 1;
			newNode.next = nextID;
			
			if(nextID < 0) {
				words.add(new OcrLetterSequence(seqID, headID, nodeID + 1,
						nodes));
				headID = nodeID + 1;
				if(nodes.size() >= maxNrNodes) {
					break;
				}
			}
		}
		reader.close();
		for(OcrLetterNode node : nodes) {
			node.word = words.get(node.sequenceID);
		}
	}

	public static void loadOCRNodesByFold(String dataPath,
			ArrayList<OcrLetterNode> nodes, ArrayList<OcrLetterSequence> words,
			int[] foldIds) throws NumberFormatException, IOException {
		String currLine;
		BufferedReader reader = new BufferedReader(new FileReader(dataPath));
		int headID = 0;
		HashSet<Integer> folds = new HashSet<Integer>();
		for(int id : foldIds) { 
			folds.add(id); 
		}
		int currSeq = -1;
		while ((currLine = reader.readLine()) != null) {
			String[] info = currLine.trim().split("\t");
			int nodeID = nodes.size();
			char letter = info[1].charAt(0) ;
			int nextID = Integer.parseInt(info[2]) - 1;
			int seqID = Integer.parseInt(info[3]) - 1;
			int seqPos = Integer.parseInt(info[4]) - 1;
			int foldID = Integer.parseInt(info[5]) - 1;
			if (!folds.contains(foldID)) { 
				continue;
			}
			if (seqID != currSeq) {
				currSeq = seqID;
				headID = nodeID;
			}
			double[] pixels = new double[info.length - 6];
			for (int i = 6; i < info.length; i++) {
				pixels[i-6] = info[i].charAt(0) - '0';
			}
			OcrLetterNode newNode = new OcrLetterNode(nodeID, words.size(),
					seqPos, letter, pixels); 
			nodes.add(newNode);
			newNode.prev = nodeID == headID ? -1 : nodeID - 1;
			newNode.next = nextID;
			
			if(nextID < 0) {
				words.add(new OcrLetterSequence(words.size(), headID,
						nodeID + 1, nodes));
			}
		}
 
		reader.close();
		for (OcrLetterNode node : nodes) {
			node.word = words.get(node.sequenceID);
		}
		
		System.out.println("Number of nodes: " + nodes.size() + "\t" +
				"Number of sequences: " + words.size());
	}
}
