package data;

public class OcrLetterNode {
	public int nodeID, sequenceID, sequencePosition;
	public int prev, next;
	public char letter;
	public double[] pixels; 
	public double l2norm;
	public OcrLetterSequence word;
	
	public OcrLetterNode(int nodeID, int sequenceID, int sequencePosition,
			char letter, double[] pixels) {
		this.nodeID = nodeID;
		this.sequenceID = sequenceID;
		this.sequencePosition = sequencePosition;
		this.letter = letter;
		this.pixels = pixels;
		for (double p : pixels) {
			l2norm += p;
		}
		l2norm = Math.sqrt(l2norm);
	}
	
	public double cosineSimilarity(OcrLetterNode otherNode) {
		double sim = .0;
		for (int i = 0; i < pixels.length; i++) {
			sim += pixels[i] * otherNode.pixels[i];
		}
		return sim / l2norm / otherNode.l2norm;
	}
}
